package com.crontiers.drugfill.Model;

import java.io.Serializable;
import java.math.BigInteger;

// ~krime
public class Account implements Serializable, MvConfig {
    private BigInteger userId;
    private String username;
    private String name;

    public BigInteger getUserId() {
        return userId;
    }

    public void setUserId(BigInteger userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
