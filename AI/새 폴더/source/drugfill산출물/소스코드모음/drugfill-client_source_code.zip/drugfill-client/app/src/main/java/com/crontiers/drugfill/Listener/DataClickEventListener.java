package com.crontiers.drugfill.Listener;

/**
 * Created by Jaewoo on 2017-08-29.
 */
public interface DataClickEventListener {
    void onClickEvent(int position, boolean select);
}
