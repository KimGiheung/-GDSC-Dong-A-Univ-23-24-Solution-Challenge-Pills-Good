package com.crontiers.drugfill.Listener;

/**
 * Created by Jaewoo on 2019-11-22.
 */
public interface FinishClickEventListener {
    void onFinishEvent(boolean b);
}
